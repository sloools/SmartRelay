package com.hyunsoo.product.beans;

import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "users")
public class User {
    @Id
    private String userId;

    private List<String> deviceId;

    public String getUserId() {
        return userId;
    }

    public List<String> getDeviceId() {
        return deviceId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setDeviceId(List<String> deviceId) {
        this.deviceId = deviceId;
    }

}
