package com.hyunsoo.product.runners;

import java.util.ArrayList;
import java.util.List;

import com.hyunsoo.product.beans.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

@Component
public class AppRunner implements ApplicationRunner {

    final MongoTemplate mongoTemplate;

    @Autowired
    public AppRunner(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        System.out.println("insert");
        User user = new User();
        List<String> deviceIdList = new ArrayList<>();
        deviceIdList.add("device-1");
        deviceIdList.add("device-2");

        user.setUserId("testId");
        user.setDeviceId(deviceIdList);

        mongoTemplate.insert(user);
        System.out.println("read");
        Query query = new Query();
        query.addCriteria(Criteria.where("userId").is("testId"));
        User _user = mongoTemplate.findOne(query, User.class);
        System.out.println(_user.getUserId());
        System.out.println(_user.getDeviceId().toString());

    }

}
