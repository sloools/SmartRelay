package com.boot.smartrelay.beans;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDataBean {
    private String onOff;
    private String mode;
    private String startTime;
    private String endTime;
}
